# MotionLab (Milestone 1)

Early Android motion-graphics editor. Original app, Kotlin + Jetpack Compose.

## What works now
- Create, open, rename, duplicate, delete projects (stored as JSON in app storage, with a .bak copy and autosave)
- Editor: rectangle / ellipse / text layers, tap to select, drag to move
- Layers tab: add, hide/show, lock/unlock, reorder (Up/Down), duplicate, delete
- Properties tab: name, text, position, size, rotation, opacity, in/out frames, colour
- Timeline tab: layer bars with in/out, drag to scrub; Play/Pause; frame slider
- Undo / Redo
- Portrait and landscape layouts

## Not built yet (planned, in this order)
Keyframes and easing, multi-select/grouping, media and image-sequence import, SVG, text animation presets, 3D import/viewport/materials/shadow catcher, renderer, resilient export queue.
Ray tracing / RTX-style rendering will only ever be offered where the phone really supports it.

## Get an APK without installing anything (GitHub)
1. Make a free account at github.com and create a new repository (public or private).
2. Upload everything in this folder to it (Add file > Upload files). Make sure the hidden folder `.github` is included.
   If it is missing: Add file > Create new file, type the name `.github/workflows/build.yml`, and paste the contents of that file from this folder.
3. Open the repository's Actions tab. The "Build APK" run starts by itself (or choose Build APK > Run workflow). It takes about 5-8 minutes.
4. Open the finished run, scroll to Artifacts, download `MotionLab-debug-apk` (a zip), unzip it to get `app-debug.apk`.
5. Copy the APK to your phone, open it, and allow "Install unknown apps" when asked.

## Or build with Android Studio
Install Android Studio, choose Open and select this folder, wait for sync, then Build > Build APK(s).

## Known limits
- Written without being able to compile it in my sandbox, so the first build may show an error. Copy it back to me and I will fix it.
- Debug-signed APK only (fine for personal installs, not for Play Store).
- Numeric typing for property values is planned; for now use the sliders.
