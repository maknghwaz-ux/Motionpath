package com.example.motionlab

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.roundToInt

/** All editor state plus undo/redo. Snapshots are whole (immutable) Project objects. */
class EditorState(initial: Project) {
    var project by mutableStateOf(initial)
        private set
    var selectedId by mutableStateOf<String?>(null)
    var frame by mutableStateOf(0)
    var playing by mutableStateOf(false)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var saveStatus by mutableStateOf("Saved")

    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()
    private var liveOpen = false

    val selected: Layer? get() = project.layers.firstOrNull { it.id == selectedId }

    private fun refresh() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun pushUndo() {
        undoStack.addLast(project)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        refresh()
    }

    private fun put(p: Project) {
        project = p.copy(modified = System.currentTimeMillis())
        saveStatus = "Unsaved changes"
    }

    /** One undo step per call. */
    fun commit(transform: (Project) -> Project) {
        endLive()
        pushUndo()
        put(transform(project))
    }

    /** Continuous edits (dragging, sliders, typing): one undo step until endLive(). */
    fun liveEdit(transform: (Project) -> Project) {
        if (!liveOpen) {
            pushUndo()
            liveOpen = true
        }
        put(transform(project))
    }

    fun endLive() {
        liveOpen = false
    }

    fun undo() {
        endLive()
        if (undoStack.isEmpty()) return
        redoStack.addLast(project)
        project = undoStack.removeLast()
        saveStatus = "Unsaved changes"
        fixSelection()
        refresh()
    }

    fun redo() {
        endLive()
        if (redoStack.isEmpty()) return
        undoStack.addLast(project)
        project = redoStack.removeLast()
        saveStatus = "Unsaved changes"
        fixSelection()
        refresh()
    }

    private fun fixSelection() {
        if (project.layers.none { it.id == selectedId }) selectedId = null
    }

    fun editLayer(id: String, live: Boolean = false, f: (Layer) -> Layer) {
        val t = { p: Project -> p.copy(layers = p.layers.map { if (it.id == id) f(it) else it }) }
        if (live) liveEdit(t) else commit(t)
    }

    fun addLayer(type: String) {
        val l = newLayer(type, project)
        commit { it.copy(layers = listOf(l) + it.layers) }
        selectedId = l.id
    }

    fun deleteSelected() {
        val id = selectedId ?: return
        commit { p -> p.copy(layers = p.layers.filter { it.id != id }) }
        selectedId = null
    }

    fun duplicateSelected() {
        val l = selected ?: return
        val copy = l.copy(id = UUID.randomUUID().toString(), name = l.name + " copy", x = l.x + 40f, y = l.y + 40f)
        commit { p ->
            val i = p.layers.indexOfFirst { it.id == l.id }
            val list = p.layers.toMutableList()
            list.add(i, copy)
            p.copy(layers = list)
        }
        selectedId = copy.id
    }

    fun moveSelected(delta: Int) {
        val id = selectedId ?: return
        val i = project.layers.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= project.layers.size) return
        commit { p ->
            val list = p.layers.toMutableList()
            val item = list.removeAt(i)
            list.add(j, item)
            p.copy(layers = list)
        }
    }

    fun hit(px: Float, py: Float): Layer? = project.layers.firstOrNull {
        it.visible && frame in it.inFrame..it.outFrame &&
            px >= it.x && px <= it.x + it.w && py >= it.y && py <= it.y + it.h
    }
}

@Composable
fun EditorScreen(initial: Project, store: ProjectStore, onClose: () -> Unit) {
    val state = remember(initial.id) { EditorState(initial) }

    BackHandler {
        store.save(state.project)
        onClose()
    }
    DisposableEffect(state) { onDispose { store.save(state.project) } }
    // Autosave shortly after each change.
    LaunchedEffect(state.project) {
        val snapshot = state.project
        delay(800)
        withContext(Dispatchers.IO) { store.save(snapshot) }
        state.saveStatus = "Saved"
    }
    LaunchedEffect(state.playing) {
        while (state.playing) {
            delay(1000L / state.project.fps)
            state.frame = if (state.frame + 1 >= state.project.duration) 0 else state.frame + 1
        }
    }

    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    Column(Modifier.fillMaxSize()) {
        TopBar(state) {
            store.save(state.project)
            onClose()
        }
        if (landscape) {
            Row(Modifier.fillMaxWidth().weight(1f)) {
                Column(Modifier.weight(1f).padding(8.dp)) {
                    PreviewCanvas(state, Modifier.fillMaxWidth())
                    Transport(state)
                }
                Panels(state, Modifier.weight(1f).fillMaxHeight())
            }
        } else {
            PreviewCanvas(state, Modifier.fillMaxWidth())
            Transport(state)
            Panels(state, Modifier.weight(1f).fillMaxWidth())
        }
    }
}

@Composable
private fun TopBar(state: EditorState, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("Back") }
        Column(Modifier.weight(1f)) {
            Text(state.project.name, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(state.saveStatus, style = MaterialTheme.typography.labelSmall)
        }
        TextButton(onClick = { state.undo() }, enabled = state.canUndo) { Text("Undo") }
        TextButton(onClick = { state.redo() }, enabled = state.canRedo) { Text("Redo") }
    }
}

@Composable
private fun PreviewCanvas(state: EditorState, modifier: Modifier) {
    val p = state.project
    Canvas(
        modifier = modifier
            .aspectRatio(p.width.toFloat() / p.height.toFloat())
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures { off ->
                    val s = size.width / state.project.width.toFloat()
                    state.selectedId = state.hit(off.x / s, off.y / s)?.id
                }
            }
            .pointerInput(Unit) {
                var target: String? = null
                detectDragGestures(
                    onDragStart = { off ->
                        val s = size.width / state.project.width.toFloat()
                        val l = state.hit(off.x / s, off.y / s)
                        target = if (l != null && !l.locked) l.id else null
                        if (l != null) state.selectedId = l.id
                    },
                    onDragEnd = { state.endLive() },
                    onDragCancel = { state.endLive() }
                ) { change, drag ->
                    change.consume()
                    val s = size.width / state.project.width.toFloat()
                    val id = target
                    if (id != null) {
                        state.editLayer(id, live = true) { it.copy(x = it.x + drag.x / s, y = it.y + drag.y / s) }
                    }
                }
            }
    ) {
        val s = size.width / p.width.toFloat()
        p.layers.asReversed().forEach { l ->
            if (!l.visible || state.frame !in l.inFrame..l.outFrame) return@forEach
            val c = Color(l.color).copy(alpha = l.opacity)
            val tl = Offset(l.x * s, l.y * s)
            val sz = Size(l.w * s, l.h * s)
            rotate(l.rotation, pivot = Offset(tl.x + sz.width / 2f, tl.y + sz.height / 2f)) {
                when (l.type) {
                    "rect" -> drawRect(c, tl, sz)
                    "ellipse" -> drawOval(c, tl, sz)
                    else -> {
                        val paint = android.graphics.Paint().apply {
                            isAntiAlias = true
                            color = c.toArgb()
                            textSize = sz.height * 0.7f
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        drawContext.canvas.nativeCanvas.drawText(
                            l.text, tl.x + sz.width / 2f, tl.y + sz.height / 2f + paint.textSize * 0.35f, paint
                        )
                    }
                }
                if (l.id == state.selectedId) {
                    drawRect(Color.White, tl, sz, style = Stroke(width = 3f))
                }
            }
        }
    }
}

@Composable
private fun Transport(state: EditorState) {
    val p = state.project
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { state.playing = !state.playing }) { Text(if (state.playing) "Pause" else "Play") }
            Spacer(Modifier.width(12.dp))
            Text("Frame ${state.frame + 1} / ${p.duration}  -  %.2fs".format(state.frame / p.fps.toFloat()))
        }
        Slider(
            value = state.frame.toFloat(),
            onValueChange = { state.frame = it.toInt() },
            valueRange = 0f..(p.duration - 1).toFloat()
        )
    }
}

@Composable
private fun Panels(state: EditorState, modifier: Modifier) {
    var tab by remember { mutableStateOf(0) }
    Column(modifier) {
        TabRow(selectedTabIndex = tab) {
            listOf("Layers", "Properties", "Timeline").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> LayersTab(state)
                1 -> PropertiesTab(state)
                else -> TimelineTab(state)
            }
        }
    }
}

@Composable
private fun LayersTab(state: EditorState) {
    val p = state.project
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { state.addLayer("rect") }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) {
                Text("+ Rectangle", maxLines = 1, fontSize = 13.sp)
            }
            Button(onClick = { state.addLayer("ellipse") }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) {
                Text("+ Ellipse", maxLines = 1, fontSize = 13.sp)
            }
            Button(onClick = { state.addLayer("text") }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) {
                Text("+ Text", maxLines = 1, fontSize = 13.sp)
            }
        }
        if (state.selected != null) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { state.moveSelected(-1) }, Modifier.weight(1f), contentPadding = PaddingValues(2.dp)) {
                    Text("Up", maxLines = 1, fontSize = 13.sp)
                }
                OutlinedButton(onClick = { state.moveSelected(1) }, Modifier.weight(1f), contentPadding = PaddingValues(2.dp)) {
                    Text("Down", maxLines = 1, fontSize = 13.sp)
                }
                OutlinedButton(onClick = { state.duplicateSelected() }, Modifier.weight(1f), contentPadding = PaddingValues(2.dp)) {
                    Text("Duplicate", maxLines = 1, fontSize = 13.sp)
                }
                OutlinedButton(onClick = { state.deleteSelected() }, Modifier.weight(1f), contentPadding = PaddingValues(2.dp)) {
                    Text("Delete", maxLines = 1, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        if (p.layers.isEmpty()) {
            Text("No layers yet. Add a rectangle, ellipse or text layer above.", Modifier.padding(16.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            items(p.layers, key = { it.id }) { l ->
                val sel = l.id == state.selectedId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (sel) Color(0xFF26324A) else Color.Transparent)
                        .clickable { state.selectedId = l.id },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { state.editLayer(l.id) { it.copy(visible = !it.visible) } }) {
                        Text(if (l.visible) "Hide" else "Show", fontSize = 13.sp)
                    }
                    TextButton(onClick = { state.editLayer(l.id) { it.copy(locked = !it.locked) } }) {
                        Text(if (l.locked) "Unlock" else "Lock", fontSize = 13.sp)
                    }
                    Text(l.name, Modifier.weight(1f), maxLines = 1)
                    Text(l.type, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(end = 8.dp))
                }
            }
        }
    }
}

@Composable
private fun PropSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    onChange: (Float) -> Unit,
    onDone: () -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            Text("%.1f".format(value), style = MaterialTheme.typography.bodySmall)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            onValueChangeFinished = onDone,
            valueRange = range,
            enabled = enabled
        )
    }
}

private val swatches = listOf(
    0xFF4F8CFF, 0xFFFF6B6B, 0xFF4ADE80, 0xFFFACC15,
    0xFFA78BFA, 0xFFFFFFFF, 0xFF111827, 0xFFFB923C
)

@Composable
private fun PropertiesTab(state: EditorState) {
    val p = state.project
    val l = state.selected
    if (l == null) {
        Text("Select a layer (tap it on the canvas or in the Layers tab) to edit its properties.", Modifier.padding(16.dp))
        return
    }
    val enabled = !l.locked
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        if (l.locked) {
            Text("This layer is locked. Unlock it in the Layers tab to edit.", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(
            value = l.name,
            onValueChange = { v -> state.editLayer(l.id, live = true) { it.copy(name = v) } },
            label = { Text("Name") },
            singleLine = true,
            enabled = enabled,
            modifier = Modifier.fillMaxWidth()
        )
        if (l.type == "text") {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = l.text,
                onValueChange = { v -> state.editLayer(l.id, live = true) { it.copy(text = v) } },
                label = { Text("Text") },
                enabled = enabled,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(8.dp))
        PropSlider("Position X", l.x, -p.width.toFloat()..p.width.toFloat() * 1.5f, enabled,
            { v -> state.editLayer(l.id, true) { it.copy(x = v) } }, { state.endLive() })
        PropSlider("Position Y", l.y, -p.height.toFloat()..p.height.toFloat() * 1.5f, enabled,
            { v -> state.editLayer(l.id, true) { it.copy(y = v) } }, { state.endLive() })
        PropSlider("Width", l.w, 10f..p.width.toFloat() * 1.5f, enabled,
            { v -> state.editLayer(l.id, true) { it.copy(w = v) } }, { state.endLive() })
        PropSlider("Height", l.h, 10f..p.height.toFloat() * 1.5f, enabled,
            { v -> state.editLayer(l.id, true) { it.copy(h = v) } }, { state.endLive() })
        PropSlider("Rotation (degrees)", l.rotation, -180f..180f, enabled,
            { v -> state.editLayer(l.id, true) { it.copy(rotation = v) } }, { state.endLive() })
        PropSlider("Opacity", l.opacity, 0f..1f, enabled,
            { v -> state.editLayer(l.id, true) { it.copy(opacity = v) } }, { state.endLive() })
        PropSlider("In frame", l.inFrame.toFloat(), 0f..(p.duration - 1).toFloat(), enabled,
            { v -> state.editLayer(l.id, true) { it.copy(inFrame = v.roundToInt()) } }, { state.endLive() })
        PropSlider("Out frame", l.outFrame.toFloat(), 0f..(p.duration - 1).toFloat(), enabled,
            { v -> state.editLayer(l.id, true) { it.copy(outFrame = v.roundToInt()) } }, { state.endLive() })
        Text("Colour", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            swatches.forEach { c ->
                var m = Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                if (l.color == c) m = m.border(3.dp, Color.White, CircleShape)
                Box(m.clickable(enabled = enabled) { state.editLayer(l.id) { it.copy(color = c) } })
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun TimelineTab(state: EditorState) {
    val p = state.project
    val rowH = 30.dp
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        if (p.layers.isEmpty()) {
            Text("Add layers to see them on the timeline. Drag here to move the playhead.", Modifier.padding(16.dp))
        }
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(rowH * maxOf(p.layers.size, 1) + 8.dp)
                .pointerInput(Unit) {
                    detectTapGestures { off ->
                        state.frame = (off.x / size.width * state.project.duration).toInt()
                            .coerceIn(0, state.project.duration - 1)
                    }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        state.frame = (change.position.x / size.width * state.project.duration).toInt()
                            .coerceIn(0, state.project.duration - 1)
                    }
                }
        ) {
            val rowPx = rowH.toPx()
            val dur = p.duration.toFloat()
            val textPaint = android.graphics.Paint().apply {
                isAntiAlias = true
                color = android.graphics.Color.WHITE
                textSize = 12.sp.toPx()
            }
            p.layers.forEachIndexed { i, l ->
                val top = 4f + i * rowPx
                val left = l.inFrame / dur * size.width
                val right = (minOf(l.outFrame, p.duration) + 1) / dur * size.width
                val barColor = if (l.id == state.selectedId) Color(0xFF4F8CFF) else Color(0xFF3B4658)
                drawRoundRect(
                    barColor.copy(alpha = if (l.visible) 1f else 0.4f),
                    Offset(left, top), Size(right - left, rowPx - 6f), CornerRadius(8f, 8f)
                )
                drawContext.canvas.nativeCanvas.drawText(l.name, left + 8f, top + rowPx * 0.55f, textPaint)
            }
            val x = state.frame / dur * size.width
            drawLine(Color(0xFFFF5252), Offset(x, 0f), Offset(x, size.height), strokeWidth = 4f)
        }
    }
}
