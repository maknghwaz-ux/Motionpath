package com.example.motionlab

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
fun HomeScreen(store: ProjectStore, onOpen: (Project) -> Unit) {
    var projects by remember { mutableStateOf(store.list()) }
    var showNew by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Project?>(null) }
    var deleteTarget by remember { mutableStateOf<Project?>(null) }
    val fmt = remember { SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("MotionLab", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Motion graphics editor - early build (Milestone 1)", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("New project") }
        Spacer(Modifier.height(12.dp))

        if (projects.isEmpty()) {
            Text("No projects yet. Tap \"New project\" to start.", Modifier.padding(vertical = 24.dp))
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(projects, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(p) }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "${p.layers.size} layers - ${p.width}x${p.height} - ${p.fps} fps - ${fmt.format(Date(p.modified))}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row {
                            TextButton(onClick = { onOpen(p) }) { Text("Open") }
                            TextButton(onClick = { renameTarget = p }) { Text("Rename") }
                            TextButton(onClick = {
                                store.save(
                                    p.copy(
                                        id = UUID.randomUUID().toString(),
                                        name = p.name + " copy",
                                        modified = System.currentTimeMillis()
                                    )
                                )
                                projects = store.list()
                            }) { Text("Duplicate") }
                            TextButton(onClick = { deleteTarget = p }) { Text("Delete") }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Roadmap", fontWeight = FontWeight.Bold)
                Text(
                    "Working now: projects, layers (rectangle, ellipse, text), move/edit, timeline scrub, playback, undo/redo, autosave.\n" +
                        "Planned: keyframes and easing, media and image-sequence import, SVG, text animation presets, 3D, rendering, export.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    if (showNew) {
        NameDialog("New project", "Untitled", "Create", { showNew = false }) { name ->
            showNew = false
            val p = Project(name = name.ifBlank { "Untitled" })
            store.save(p)
            onOpen(p)
        }
    }
    renameTarget?.let { t ->
        NameDialog("Rename project", t.name, "Rename", { renameTarget = null }) { name ->
            renameTarget = null
            store.save(t.copy(name = name.ifBlank { t.name }, modified = System.currentTimeMillis()))
            projects = store.list()
        }
    }
    deleteTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete project?") },
            text = { Text("\"${t.name}\" will be deleted. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    store.delete(t.id)
                    deleteTarget = null
                    projects = store.list()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(text.trim()) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
