package com.example.motionlab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ProjectStore(File(filesDir, "projects"))
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF4F8CFF),
                    background = Color(0xFF0F131A),
                    surface = Color(0xFF171C26)
                )
            ) {
                App(store)
            }
        }
    }
}

@Composable
fun App(store: ProjectStore) {
    var open by remember { mutableStateOf<Project?>(null) }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        val current = open
        if (current == null) {
            HomeScreen(store) { open = it }
        } else {
            EditorScreen(current, store) { open = null }
        }
    }
}
