package com.example.motionlab

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

const val FORMAT_VERSION = 1

data class Layer(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: String, // "rect", "ellipse", "text"
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val color: Long = 0xFF4F8CFF,
    val text: String = "",
    val visible: Boolean = true,
    val locked: Boolean = false,
    val inFrame: Int = 0,
    val outFrame: Int = 150
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("type", type)
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("w", w.toDouble())
        put("h", h.toDouble())
        put("rotation", rotation.toDouble())
        put("opacity", opacity.toDouble())
        put("color", color)
        put("text", text)
        put("visible", visible)
        put("locked", locked)
        put("inFrame", inFrame)
        put("outFrame", outFrame)
    }

    companion object {
        fun fromJson(o: JSONObject): Layer = Layer(
            id = o.getString("id"),
            name = o.getString("name"),
            type = o.getString("type"),
            x = o.getDouble("x").toFloat(),
            y = o.getDouble("y").toFloat(),
            w = o.getDouble("w").toFloat(),
            h = o.getDouble("h").toFloat(),
            rotation = o.optDouble("rotation", 0.0).toFloat(),
            opacity = o.optDouble("opacity", 1.0).toFloat(),
            color = o.optLong("color", 0xFF4F8CFF),
            text = o.optString("text", ""),
            visible = o.optBoolean("visible", true),
            locked = o.optBoolean("locked", false),
            inFrame = o.optInt("inFrame", 0),
            outFrame = o.optInt("outFrame", 150)
        )
    }
}

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val width: Int = 1280,
    val height: Int = 720,
    val fps: Int = 30,
    val duration: Int = 150,
    val layers: List<Layer> = emptyList(), // index 0 = top of the stack
    val modified: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("version", FORMAT_VERSION)
        put("id", id)
        put("name", name)
        put("width", width)
        put("height", height)
        put("fps", fps)
        put("duration", duration)
        put("modified", modified)
        val arr = JSONArray()
        layers.forEach { arr.put(it.toJson()) }
        put("layers", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): Project {
            val version = o.optInt("version", 1)
            if (version > FORMAT_VERSION) {
                throw IllegalStateException("Project was saved by a newer app version")
            }
            val arr = o.getJSONArray("layers")
            val layers = (0 until arr.length()).map { Layer.fromJson(arr.getJSONObject(it)) }
            return Project(
                id = o.getString("id"),
                name = o.getString("name"),
                width = o.optInt("width", 1280),
                height = o.optInt("height", 720),
                fps = o.optInt("fps", 30),
                duration = o.optInt("duration", 150),
                layers = layers,
                modified = o.optLong("modified", System.currentTimeMillis())
            )
        }
    }
}

fun newLayer(type: String, p: Project): Layer {
    val n = p.layers.count { it.type == type } + 1
    return when (type) {
        "rect" -> Layer(
            name = "Rectangle $n", type = "rect",
            x = p.width * 0.3f, y = p.height * 0.3f, w = 400f, h = 240f,
            color = 0xFF4F8CFF, outFrame = p.duration
        )
        "ellipse" -> Layer(
            name = "Ellipse $n", type = "ellipse",
            x = p.width * 0.4f, y = p.height * 0.35f, w = 300f, h = 300f,
            color = 0xFFFF6B6B, outFrame = p.duration
        )
        else -> Layer(
            name = "Text $n", type = "text",
            x = p.width * 0.25f, y = p.height * 0.4f, w = 640f, h = 120f,
            color = 0xFFFFFFFF, text = "Hello", outFrame = p.duration
        )
    }
}
