package com.example.motionlab

import org.json.JSONObject
import java.io.File

/** Saves each project as <id>.json, written via a temp file, with a .bak copy of the previous version. */
class ProjectStore(private val dir: File) {
    init {
        dir.mkdirs()
    }

    private fun read(f: File): Project? = try {
        Project.fromJson(JSONObject(f.readText()))
    } catch (e: Exception) {
        null
    }

    fun list(): List<Project> {
        val files = dir.listFiles() ?: return emptyList()
        return files
            .filter { it.name.endsWith(".json") }
            .mapNotNull { read(it) ?: read(File(dir, it.name + ".bak")) }
            .sortedByDescending { it.modified }
    }

    @Synchronized
    fun save(p: Project) {
        val target = File(dir, "${p.id}.json")
        val tmp = File(dir, "${p.id}.json.tmp")
        val bak = File(dir, "${p.id}.json.bak")
        tmp.writeText(p.toJson().toString())
        if (target.exists()) target.copyTo(bak, overwrite = true)
        if (!tmp.renameTo(target)) {
            target.delete()
            tmp.renameTo(target)
        }
    }

    @Synchronized
    fun delete(id: String) {
        File(dir, "$id.json").delete()
        File(dir, "$id.json.bak").delete()
        File(dir, "$id.json.tmp").delete()
    }
}
